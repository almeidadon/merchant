<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-12 00:08:15 --> Config Class Initialized
DEBUG - 2014-12-12 00:08:15 --> Hooks Class Initialized
DEBUG - 2014-12-12 00:08:15 --> Utf8 Class Initialized
DEBUG - 2014-12-12 00:08:15 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 00:08:15 --> URI Class Initialized
DEBUG - 2014-12-12 00:08:15 --> Router Class Initialized
ERROR - 2014-12-12 00:08:15 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 00:08:15 --> Config Class Initialized
DEBUG - 2014-12-12 00:08:15 --> Hooks Class Initialized
DEBUG - 2014-12-12 00:08:15 --> Utf8 Class Initialized
DEBUG - 2014-12-12 00:08:15 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 00:08:15 --> URI Class Initialized
DEBUG - 2014-12-12 00:08:15 --> Router Class Initialized
ERROR - 2014-12-12 00:08:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 00:48:21 --> Config Class Initialized
DEBUG - 2014-12-12 00:48:21 --> Hooks Class Initialized
DEBUG - 2014-12-12 00:48:21 --> Utf8 Class Initialized
DEBUG - 2014-12-12 00:48:21 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 00:48:21 --> URI Class Initialized
DEBUG - 2014-12-12 00:48:21 --> Router Class Initialized
ERROR - 2014-12-12 00:48:21 --> 404 Page Not Found --> signin
DEBUG - 2014-12-12 00:48:21 --> Config Class Initialized
DEBUG - 2014-12-12 00:48:21 --> Hooks Class Initialized
DEBUG - 2014-12-12 00:48:21 --> Utf8 Class Initialized
DEBUG - 2014-12-12 00:48:21 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 00:48:21 --> URI Class Initialized
DEBUG - 2014-12-12 00:48:21 --> Router Class Initialized
ERROR - 2014-12-12 00:48:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 00:48:28 --> Config Class Initialized
DEBUG - 2014-12-12 00:48:28 --> Hooks Class Initialized
DEBUG - 2014-12-12 00:48:28 --> Utf8 Class Initialized
DEBUG - 2014-12-12 00:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 00:48:28 --> URI Class Initialized
DEBUG - 2014-12-12 00:48:28 --> Router Class Initialized
ERROR - 2014-12-12 00:48:28 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 00:59:38 --> Config Class Initialized
DEBUG - 2014-12-12 00:59:38 --> Hooks Class Initialized
DEBUG - 2014-12-12 00:59:38 --> Utf8 Class Initialized
DEBUG - 2014-12-12 00:59:38 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 00:59:38 --> URI Class Initialized
DEBUG - 2014-12-12 00:59:38 --> Router Class Initialized
ERROR - 2014-12-12 00:59:38 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 01:01:43 --> Config Class Initialized
DEBUG - 2014-12-12 01:01:43 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:01:43 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:01:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:01:43 --> URI Class Initialized
DEBUG - 2014-12-12 01:01:43 --> Router Class Initialized
ERROR - 2014-12-12 01:01:43 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 01:07:30 --> Config Class Initialized
DEBUG - 2014-12-12 01:07:30 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:07:30 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:07:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:07:30 --> URI Class Initialized
DEBUG - 2014-12-12 01:07:30 --> Router Class Initialized
ERROR - 2014-12-12 01:07:30 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 01:11:52 --> Config Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:11:52 --> URI Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Router Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Output Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Security Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Input Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 01:11:52 --> Language Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Loader Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Helper loaded: url_helper
DEBUG - 2014-12-12 01:11:52 --> Controller Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 01:11:52 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 01:11:52 --> Helper loaded: form_helper
DEBUG - 2014-12-12 01:11:52 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Database Driver Class Initialized
ERROR - 2014-12-12 01:11:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 01:11:52 --> Encrypt Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 01:11:52 --> Session Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Helper loaded: string_helper
DEBUG - 2014-12-12 01:11:52 --> A session cookie was not found.
DEBUG - 2014-12-12 01:11:52 --> Session routines successfully run
DEBUG - 2014-12-12 01:11:52 --> Email Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:52 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 01:11:52 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:52 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:52 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:52 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2014-12-12 01:11:52 --> File loaded: application/views/collect_mobileNo/header.php
DEBUG - 2014-12-12 01:11:52 --> File loaded: application/views/collect_mobileNo/body.php
DEBUG - 2014-12-12 01:11:52 --> File loaded: application/views/collect_mobileNo/footer.php
DEBUG - 2014-12-12 01:11:52 --> Final output sent to browser
DEBUG - 2014-12-12 01:11:52 --> Total execution time: 0.0283
DEBUG - 2014-12-12 01:11:52 --> Config Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:11:52 --> URI Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Router Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Config Class Initialized
ERROR - 2014-12-12 01:11:52 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 01:11:52 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:11:52 --> URI Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Router Class Initialized
ERROR - 2014-12-12 01:11:52 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 01:11:52 --> Config Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:11:52 --> URI Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Router Class Initialized
ERROR - 2014-12-12 01:11:52 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 01:11:52 --> Config Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:11:52 --> URI Class Initialized
DEBUG - 2014-12-12 01:11:52 --> Router Class Initialized
ERROR - 2014-12-12 01:11:52 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 01:11:56 --> Config Class Initialized
DEBUG - 2014-12-12 01:11:56 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:11:56 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:11:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:11:56 --> URI Class Initialized
DEBUG - 2014-12-12 01:11:56 --> Router Class Initialized
DEBUG - 2014-12-12 01:11:56 --> Output Class Initialized
DEBUG - 2014-12-12 01:11:56 --> Security Class Initialized
DEBUG - 2014-12-12 01:11:56 --> Input Class Initialized
DEBUG - 2014-12-12 01:11:56 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:56 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:56 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:56 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:56 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> XSS Filtering completed
DEBUG - 2014-12-12 01:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 01:11:57 --> Language Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Loader Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Helper loaded: url_helper
DEBUG - 2014-12-12 01:11:57 --> Controller Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 01:11:57 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 01:11:57 --> Helper loaded: form_helper
DEBUG - 2014-12-12 01:11:57 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Database Driver Class Initialized
ERROR - 2014-12-12 01:11:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 01:11:57 --> Encrypt Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 01:11:57 --> Session Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Helper loaded: string_helper
DEBUG - 2014-12-12 01:11:57 --> Session routines successfully run
DEBUG - 2014-12-12 01:11:57 --> Email Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:57 --> Model Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:11:57 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 01:11:57 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:57 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:57 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:57 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:57 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:11:57 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 01:11:57 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 01:11:57 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 01:11:57 --> File loaded: application/views/payment_page/header.php
DEBUG - 2014-12-12 01:11:57 --> File loaded: application/views/payment_page/body.php
DEBUG - 2014-12-12 01:11:57 --> File loaded: application/views/payment_page/footer.php
DEBUG - 2014-12-12 01:11:57 --> Final output sent to browser
DEBUG - 2014-12-12 01:11:57 --> Total execution time: 0.0567
DEBUG - 2014-12-12 01:13:07 --> Config Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:13:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:13:07 --> URI Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Router Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Output Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Security Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Input Class Initialized
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> Config Class Initialized
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:13:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:13:07 --> URI Class Initialized
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> Router Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 01:13:07 --> Language Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Output Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Security Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Input Class Initialized
DEBUG - 2014-12-12 01:13:07 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 01:13:07 --> Language Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Loader Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: url_helper
DEBUG - 2014-12-12 01:13:07 --> Controller Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 01:13:07 --> Loader Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: form_helper
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: url_helper
DEBUG - 2014-12-12 01:13:07 --> Controller Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
ERROR - 2014-12-12 01:13:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
ERROR - 2014-12-12 01:13:07 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 01:13:07 --> Encrypt Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Encrypt Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 01:13:07 --> Session Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: string_helper
DEBUG - 2014-12-12 01:13:07 --> Session routines successfully run
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Email Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 01:13:07 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Session Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: string_helper
DEBUG - 2014-12-12 01:13:07 --> Session routines successfully run
DEBUG - 2014-12-12 01:13:07 --> Email Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 01:13:07 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:07 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 01:13:07 --> 404 Page Not Found --> processButtn/img
DEBUG - 2014-12-12 01:13:07 --> Helper loaded: form_helper
DEBUG - 2014-12-12 01:13:07 --> Form Validation Class Initialized
ERROR - 2014-12-12 01:13:15 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 01:13:15 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 01:13:15 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 01:13:15 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 01:13:15 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2014-12-12 01:13:15 --> Severity: Warning  --> mcrypt_encrypt(): Attempt to use an empty IV, which is NOT recommend /var/www/html/pay/application/libraries/Paymentgateway.php 457
DEBUG - 2014-12-12 01:13:26 --> Final output sent to browser
DEBUG - 2014-12-12 01:13:26 --> Total execution time: 18.8887
DEBUG - 2014-12-12 01:13:26 --> Config Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:13:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:13:26 --> URI Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Router Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Output Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Security Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Input Class Initialized
DEBUG - 2014-12-12 01:13:26 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 01:13:26 --> Language Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Loader Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: url_helper
DEBUG - 2014-12-12 01:13:26 --> Controller Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
ERROR - 2014-12-12 01:13:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 01:13:26 --> Encrypt Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 01:13:26 --> Session Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: string_helper
DEBUG - 2014-12-12 01:13:26 --> Session routines successfully run
DEBUG - 2014-12-12 01:13:26 --> Email Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 01:13:26 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: form_helper
DEBUG - 2014-12-12 01:13:26 --> Form Validation Class Initialized
ERROR - 2014-12-12 01:13:26 --> 404 Page Not Found --> processTransaction/images
DEBUG - 2014-12-12 01:13:26 --> Config Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Hooks Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Utf8 Class Initialized
DEBUG - 2014-12-12 01:13:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 01:13:26 --> URI Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Router Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Output Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Security Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Input Class Initialized
DEBUG - 2014-12-12 01:13:26 --> XSS Filtering completed
DEBUG - 2014-12-12 01:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 01:13:26 --> Language Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Loader Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: url_helper
DEBUG - 2014-12-12 01:13:26 --> Controller Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
ERROR - 2014-12-12 01:13:26 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 01:13:26 --> Encrypt Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 01:13:26 --> Session Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: string_helper
DEBUG - 2014-12-12 01:13:26 --> Session routines successfully run
DEBUG - 2014-12-12 01:13:26 --> Email Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Model Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Database Driver Class Initialized
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 01:13:26 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 01:13:26 --> Helper loaded: form_helper
DEBUG - 2014-12-12 01:13:26 --> Form Validation Class Initialized
ERROR - 2014-12-12 01:13:26 --> 404 Page Not Found --> processTransaction/images
DEBUG - 2014-12-12 10:13:27 --> Config Class Initialized
DEBUG - 2014-12-12 10:13:27 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:13:27 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:13:27 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:13:27 --> URI Class Initialized
DEBUG - 2014-12-12 10:13:27 --> Router Class Initialized
ERROR - 2014-12-12 10:13:27 --> 404 Page Not Found --> signin
DEBUG - 2014-12-12 10:13:28 --> Config Class Initialized
DEBUG - 2014-12-12 10:13:28 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:13:28 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:13:28 --> URI Class Initialized
DEBUG - 2014-12-12 10:13:28 --> Router Class Initialized
ERROR - 2014-12-12 10:13:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 10:17:40 --> Config Class Initialized
DEBUG - 2014-12-12 10:17:40 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:17:40 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:17:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:17:40 --> URI Class Initialized
DEBUG - 2014-12-12 10:17:40 --> Router Class Initialized
ERROR - 2014-12-12 10:17:40 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 10:17:40 --> Config Class Initialized
DEBUG - 2014-12-12 10:17:40 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:17:40 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:17:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:17:40 --> URI Class Initialized
DEBUG - 2014-12-12 10:17:40 --> Router Class Initialized
ERROR - 2014-12-12 10:17:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 10:38:18 --> Config Class Initialized
DEBUG - 2014-12-12 10:38:18 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:38:18 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:38:18 --> URI Class Initialized
DEBUG - 2014-12-12 10:38:18 --> Router Class Initialized
ERROR - 2014-12-12 10:38:18 --> 404 Page Not Found --> signin
DEBUG - 2014-12-12 10:38:18 --> Config Class Initialized
DEBUG - 2014-12-12 10:38:18 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:38:18 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:38:18 --> URI Class Initialized
DEBUG - 2014-12-12 10:38:18 --> Router Class Initialized
ERROR - 2014-12-12 10:38:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 10:38:24 --> Config Class Initialized
DEBUG - 2014-12-12 10:38:24 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:38:24 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:38:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:38:24 --> URI Class Initialized
DEBUG - 2014-12-12 10:38:24 --> Router Class Initialized
ERROR - 2014-12-12 10:38:24 --> 404 Page Not Found --> signin
DEBUG - 2014-12-12 10:57:44 --> Config Class Initialized
DEBUG - 2014-12-12 10:57:44 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:57:44 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:57:44 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:57:44 --> URI Class Initialized
DEBUG - 2014-12-12 10:57:44 --> Router Class Initialized
ERROR - 2014-12-12 10:57:44 --> 404 Page Not Found --> signin
DEBUG - 2014-12-12 10:57:44 --> Config Class Initialized
DEBUG - 2014-12-12 10:57:44 --> Hooks Class Initialized
DEBUG - 2014-12-12 10:57:44 --> Utf8 Class Initialized
DEBUG - 2014-12-12 10:57:44 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 10:57:44 --> URI Class Initialized
DEBUG - 2014-12-12 10:57:44 --> Router Class Initialized
ERROR - 2014-12-12 10:57:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:01:20 --> Config Class Initialized
DEBUG - 2014-12-12 11:01:20 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:01:20 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:01:20 --> URI Class Initialized
DEBUG - 2014-12-12 11:01:20 --> Router Class Initialized
ERROR - 2014-12-12 11:01:20 --> 404 Page Not Found --> signin
DEBUG - 2014-12-12 11:03:24 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:24 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Router Class Initialized
ERROR - 2014-12-12 11:03:24 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 11:03:24 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:24 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Router Class Initialized
ERROR - 2014-12-12 11:03:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:03:24 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:24 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:24 --> Router Class Initialized
ERROR - 2014-12-12 11:03:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:03:29 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:29 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Router Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Output Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Security Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Input Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:03:29 --> Language Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Loader Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:03:29 --> Controller Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:03:29 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:03:29 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:03:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:03:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:03:29 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:03:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:03:29 --> Session Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:03:29 --> A session cookie was not found.
DEBUG - 2014-12-12 11:03:29 --> Session routines successfully run
DEBUG - 2014-12-12 11:03:29 --> Email Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:03:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:03:29 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:03:29 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:03:29 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:03:29 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:03:29 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:03:29 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:03:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2014-12-12 11:03:29 --> File loaded: application/views/collect_mobileNo/header.php
DEBUG - 2014-12-12 11:03:29 --> File loaded: application/views/collect_mobileNo/body.php
DEBUG - 2014-12-12 11:03:29 --> File loaded: application/views/collect_mobileNo/footer.php
DEBUG - 2014-12-12 11:03:29 --> Final output sent to browser
DEBUG - 2014-12-12 11:03:29 --> Total execution time: 0.0854
DEBUG - 2014-12-12 11:03:30 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:30 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Router Class Initialized
ERROR - 2014-12-12 11:03:30 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:03:30 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:30 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Router Class Initialized
ERROR - 2014-12-12 11:03:30 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:03:30 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:30 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Router Class Initialized
ERROR - 2014-12-12 11:03:30 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:03:30 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:30 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:30 --> Router Class Initialized
ERROR - 2014-12-12 11:03:30 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:03:31 --> Config Class Initialized
DEBUG - 2014-12-12 11:03:31 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:03:31 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:03:31 --> URI Class Initialized
DEBUG - 2014-12-12 11:03:31 --> Router Class Initialized
ERROR - 2014-12-12 11:03:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:04:33 --> Config Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:04:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:04:33 --> URI Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Router Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Output Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Security Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Input Class Initialized
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> XSS Filtering completed
DEBUG - 2014-12-12 11:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:04:33 --> Language Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Loader Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:04:33 --> Controller Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:04:33 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:04:33 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:04:33 --> Model Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Model Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Model Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:04:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:04:33 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Model Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Model Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:04:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:04:33 --> Session Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:04:33 --> Session routines successfully run
DEBUG - 2014-12-12 11:04:33 --> Email Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:04:33 --> Model Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:04:33 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:04:33 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:04:33 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:04:33 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:04:33 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:04:33 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:04:33 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 11:04:33 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:04:33 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:04:33 --> File loaded: application/views/payment_page/header.php
DEBUG - 2014-12-12 11:04:33 --> File loaded: application/views/payment_page/body.php
DEBUG - 2014-12-12 11:04:33 --> File loaded: application/views/payment_page/footer.php
DEBUG - 2014-12-12 11:04:33 --> Final output sent to browser
DEBUG - 2014-12-12 11:04:33 --> Total execution time: 0.0634
DEBUG - 2014-12-12 11:05:49 --> Config Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:05:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:05:49 --> URI Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Router Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Output Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Security Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Input Class Initialized
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:05:49 --> Language Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Loader Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:05:49 --> Controller Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:05:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:05:49 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:05:49 --> Session Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:05:49 --> Session routines successfully run
DEBUG - 2014-12-12 11:05:49 --> Email Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:05:49 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:05:49 --> Form Validation Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Config Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:05:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:05:49 --> URI Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Router Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Output Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Security Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Input Class Initialized
DEBUG - 2014-12-12 11:05:49 --> XSS Filtering completed
DEBUG - 2014-12-12 11:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:05:49 --> Language Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Loader Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:05:49 --> Controller Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:05:49 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:05:49 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:05:49 --> Session Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:05:49 --> Session routines successfully run
DEBUG - 2014-12-12 11:05:49 --> Email Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Model Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:05:49 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:05:49 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:05:49 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 11:05:49 --> 404 Page Not Found --> processInvoiz/img
ERROR - 2014-12-12 11:05:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:05:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:05:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:05:56 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:05:56 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2014-12-12 11:05:56 --> Severity: Warning  --> mcrypt_encrypt(): Attempt to use an empty IV, which is NOT recommend /var/www/html/pay/application/libraries/Paymentgateway.php 457
DEBUG - 2014-12-12 11:06:02 --> Final output sent to browser
DEBUG - 2014-12-12 11:06:02 --> Total execution time: 13.0124
DEBUG - 2014-12-12 11:06:02 --> Config Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:06:02 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:06:02 --> URI Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Router Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Output Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Security Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Input Class Initialized
DEBUG - 2014-12-12 11:06:02 --> XSS Filtering completed
DEBUG - 2014-12-12 11:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:06:02 --> Language Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Loader Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:06:02 --> Controller Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:06:02 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:06:02 --> Model Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Model Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Model Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:06:02 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:06:02 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Model Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Model Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:06:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:06:02 --> Session Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:06:02 --> Session routines successfully run
DEBUG - 2014-12-12 11:06:02 --> Email Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:06:02 --> Model Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:06:02 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:06:02 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:06:02 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:06:02 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:06:02 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:06:02 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:06:02 --> Form Validation Class Initialized
ERROR - 2014-12-12 11:06:02 --> 404 Page Not Found --> processTransaction/images
DEBUG - 2014-12-12 11:08:23 --> Config Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:08:23 --> URI Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Router Class Initialized
ERROR - 2014-12-12 11:08:23 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 11:08:23 --> Config Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:08:23 --> URI Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Router Class Initialized
ERROR - 2014-12-12 11:08:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:08:23 --> Config Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:08:23 --> URI Class Initialized
DEBUG - 2014-12-12 11:08:23 --> Router Class Initialized
ERROR - 2014-12-12 11:08:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:14:29 --> Config Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:14:29 --> URI Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Router Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Output Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Security Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Input Class Initialized
DEBUG - 2014-12-12 11:14:29 --> XSS Filtering completed
DEBUG - 2014-12-12 11:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:14:29 --> Language Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Loader Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:14:29 --> Controller Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:14:29 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:14:29 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:14:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:14:29 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:14:29 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:14:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:14:29 --> Session Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:14:29 --> Session routines successfully run
DEBUG - 2014-12-12 11:14:29 --> Email Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:14:29 --> Model Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:14:29 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:14:29 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:14:29 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:14:29 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:14:29 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:14:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2014-12-12 11:14:29 --> File loaded: application/views/collect_mobileNo/header.php
DEBUG - 2014-12-12 11:14:29 --> File loaded: application/views/collect_mobileNo/body.php
DEBUG - 2014-12-12 11:14:29 --> File loaded: application/views/collect_mobileNo/footer.php
DEBUG - 2014-12-12 11:14:29 --> Final output sent to browser
DEBUG - 2014-12-12 11:14:29 --> Total execution time: 0.0771
DEBUG - 2014-12-12 11:14:29 --> Config Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:14:29 --> URI Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Router Class Initialized
ERROR - 2014-12-12 11:14:29 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:14:29 --> Config Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:14:29 --> URI Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Router Class Initialized
ERROR - 2014-12-12 11:14:29 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:14:29 --> Config Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:14:29 --> URI Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Router Class Initialized
ERROR - 2014-12-12 11:14:29 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:14:29 --> Config Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:14:29 --> URI Class Initialized
DEBUG - 2014-12-12 11:14:29 --> Router Class Initialized
ERROR - 2014-12-12 11:14:29 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:16:44 --> Config Class Initialized
DEBUG - 2014-12-12 11:16:44 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:16:44 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:16:44 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:16:44 --> URI Class Initialized
DEBUG - 2014-12-12 11:16:44 --> Router Class Initialized
ERROR - 2014-12-12 11:16:44 --> 404 Page Not Found --> signin
DEBUG - 2014-12-12 11:16:44 --> Config Class Initialized
DEBUG - 2014-12-12 11:16:44 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:16:44 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:16:44 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:16:44 --> URI Class Initialized
DEBUG - 2014-12-12 11:16:44 --> Router Class Initialized
ERROR - 2014-12-12 11:16:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:16:48 --> Config Class Initialized
DEBUG - 2014-12-12 11:16:48 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:16:48 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:16:48 --> URI Class Initialized
DEBUG - 2014-12-12 11:16:48 --> Router Class Initialized
ERROR - 2014-12-12 11:16:48 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 11:32:26 --> Config Class Initialized
DEBUG - 2014-12-12 11:32:26 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:32:26 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:32:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:32:26 --> URI Class Initialized
DEBUG - 2014-12-12 11:32:26 --> Router Class Initialized
ERROR - 2014-12-12 11:32:26 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 11:35:13 --> Config Class Initialized
DEBUG - 2014-12-12 11:35:13 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:35:13 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:35:13 --> URI Class Initialized
DEBUG - 2014-12-12 11:35:13 --> Router Class Initialized
ERROR - 2014-12-12 11:35:13 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-12 11:35:13 --> Config Class Initialized
DEBUG - 2014-12-12 11:35:13 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:35:13 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:35:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:35:13 --> URI Class Initialized
DEBUG - 2014-12-12 11:35:13 --> Router Class Initialized
ERROR - 2014-12-12 11:35:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-12 11:37:48 --> Config Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:37:48 --> URI Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Router Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Output Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Security Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Input Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:37:48 --> Language Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Loader Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:37:48 --> Controller Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:37:48 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:37:48 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:37:48 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:37:48 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:37:48 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:37:48 --> Session Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:37:48 --> A session cookie was not found.
DEBUG - 2014-12-12 11:37:48 --> Session routines successfully run
DEBUG - 2014-12-12 11:37:48 --> Email Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:48 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:48 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:37:48 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:48 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:48 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:48 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:48 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2014-12-12 11:37:48 --> File loaded: application/views/collect_mobileNo/header.php
DEBUG - 2014-12-12 11:37:48 --> File loaded: application/views/collect_mobileNo/body.php
DEBUG - 2014-12-12 11:37:48 --> File loaded: application/views/collect_mobileNo/footer.php
DEBUG - 2014-12-12 11:37:48 --> Final output sent to browser
DEBUG - 2014-12-12 11:37:48 --> Total execution time: 0.0544
DEBUG - 2014-12-12 11:37:49 --> Config Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:37:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:37:49 --> URI Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Router Class Initialized
ERROR - 2014-12-12 11:37:49 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:37:49 --> Config Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:37:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:37:49 --> URI Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Router Class Initialized
ERROR - 2014-12-12 11:37:49 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:37:49 --> Config Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:37:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:37:49 --> URI Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Router Class Initialized
ERROR - 2014-12-12 11:37:49 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:37:49 --> Config Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:37:49 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:37:49 --> URI Class Initialized
DEBUG - 2014-12-12 11:37:49 --> Router Class Initialized
ERROR - 2014-12-12 11:37:49 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:37:52 --> Config Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:37:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:37:52 --> URI Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Router Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Output Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Security Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Input Class Initialized
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> XSS Filtering completed
DEBUG - 2014-12-12 11:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:37:52 --> Language Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Loader Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:37:52 --> Controller Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:37:52 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:37:52 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:37:52 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:52 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:37:52 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:37:53 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:37:53 --> Session Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:37:53 --> Session routines successfully run
DEBUG - 2014-12-12 11:37:53 --> Email Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:53 --> Model Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:37:53 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:37:53 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:53 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:53 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:53 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:53 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:37:53 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 11:37:53 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:37:53 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:37:53 --> File loaded: application/views/payment_page/header.php
DEBUG - 2014-12-12 11:37:53 --> File loaded: application/views/payment_page/body.php
DEBUG - 2014-12-12 11:37:53 --> File loaded: application/views/payment_page/footer.php
DEBUG - 2014-12-12 11:37:53 --> Final output sent to browser
DEBUG - 2014-12-12 11:37:53 --> Total execution time: 0.7992
DEBUG - 2014-12-12 11:38:31 --> Config Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:38:31 --> URI Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Router Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Output Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Security Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Input Class Initialized
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:38:31 --> Language Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Loader Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:38:31 --> Controller Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:38:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:38:31 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:38:31 --> Session Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:38:31 --> Session routines successfully run
DEBUG - 2014-12-12 11:38:31 --> Email Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:38:31 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:38:31 --> Form Validation Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Config Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:38:31 --> URI Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Router Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Output Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Security Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Input Class Initialized
DEBUG - 2014-12-12 11:38:31 --> XSS Filtering completed
DEBUG - 2014-12-12 11:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:38:31 --> Language Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Loader Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:38:31 --> Controller Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:38:31 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:38:31 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:38:31 --> Session Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:38:31 --> Session routines successfully run
DEBUG - 2014-12-12 11:38:31 --> Email Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Model Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:38:31 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:38:31 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:38:31 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 11:38:31 --> 404 Page Not Found --> processButtn/img
ERROR - 2014-12-12 11:38:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:38:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:38:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:38:38 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:38:38 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2014-12-12 11:38:38 --> Severity: Warning  --> mcrypt_encrypt(): Attempt to use an empty IV, which is NOT recommend /var/www/html/pay/application/libraries/Paymentgateway.php 457
DEBUG - 2014-12-12 11:38:44 --> Final output sent to browser
DEBUG - 2014-12-12 11:38:44 --> Total execution time: 12.5982
DEBUG - 2014-12-12 11:45:55 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:55 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Router Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Output Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Security Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:55 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Router Class Initialized
ERROR - 2014-12-12 11:45:55 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:45:55 --> Input Class Initialized
DEBUG - 2014-12-12 11:45:55 --> XSS Filtering completed
DEBUG - 2014-12-12 11:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:45:55 --> Language Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Loader Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:45:55 --> Controller Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:45:55 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:45:55 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:45:55 --> Model Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Model Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Model Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:45:55 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:45:55 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:55 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Router Class Initialized
ERROR - 2014-12-12 11:45:55 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:45:55 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:55 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Router Class Initialized
ERROR - 2014-12-12 11:45:55 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:45:55 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Model Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Model Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:45:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:45:55 --> Session Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:45:55 --> Session routines successfully run
DEBUG - 2014-12-12 11:45:55 --> Email Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:45:55 --> Model Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:45:55 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:45:55 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:45:55 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:45:55 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:45:55 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:45:55 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:45:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2014-12-12 11:45:55 --> File loaded: application/views/collect_mobileNo/header.php
DEBUG - 2014-12-12 11:45:55 --> File loaded: application/views/collect_mobileNo/body.php
DEBUG - 2014-12-12 11:45:55 --> File loaded: application/views/collect_mobileNo/footer.php
DEBUG - 2014-12-12 11:45:55 --> Final output sent to browser
DEBUG - 2014-12-12 11:45:55 --> Total execution time: 0.0657
DEBUG - 2014-12-12 11:45:57 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:57 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Router Class Initialized
ERROR - 2014-12-12 11:45:57 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:45:57 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:57 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Router Class Initialized
ERROR - 2014-12-12 11:45:57 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:45:57 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:57 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Router Class Initialized
ERROR - 2014-12-12 11:45:57 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:45:57 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:57 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:57 --> Router Class Initialized
ERROR - 2014-12-12 11:45:57 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:45:58 --> Config Class Initialized
DEBUG - 2014-12-12 11:45:58 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:45:58 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:45:58 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:45:58 --> URI Class Initialized
DEBUG - 2014-12-12 11:45:58 --> Router Class Initialized
ERROR - 2014-12-12 11:45:58 --> 404 Page Not Found --> assets
DEBUG - 2014-12-12 11:46:01 --> Config Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:46:01 --> URI Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Router Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Output Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Security Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Input Class Initialized
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:46:01 --> Language Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Loader Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:46:01 --> Controller Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:46:01 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:46:01 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:46:01 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:46:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:46:01 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:46:01 --> Session Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:46:01 --> Session routines successfully run
DEBUG - 2014-12-12 11:46:01 --> Email Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:01 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:01 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:46:01 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:01 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:01 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:01 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:01 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:01 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 11:46:01 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:46:01 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:46:01 --> File loaded: application/views/payment_page/header.php
DEBUG - 2014-12-12 11:46:01 --> File loaded: application/views/payment_page/body.php
DEBUG - 2014-12-12 11:46:01 --> File loaded: application/views/payment_page/footer.php
DEBUG - 2014-12-12 11:46:01 --> Final output sent to browser
DEBUG - 2014-12-12 11:46:01 --> Total execution time: 0.0435
DEBUG - 2014-12-12 11:46:25 --> Config Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:46:25 --> URI Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Router Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Output Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Security Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Input Class Initialized
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:46:25 --> Language Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Loader Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:46:25 --> Controller Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:46:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:46:25 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:46:25 --> Session Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:46:25 --> Session routines successfully run
DEBUG - 2014-12-12 11:46:25 --> Email Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:46:25 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Config Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:46:25 --> URI Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Router Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Output Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Security Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Input Class Initialized
DEBUG - 2014-12-12 11:46:25 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:46:25 --> Language Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Loader Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:46:25 --> Controller Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:46:25 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:46:25 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:46:25 --> Form Validation Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:46:25 --> Session Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:46:25 --> Session routines successfully run
DEBUG - 2014-12-12 11:46:25 --> Email Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:25 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:46:25 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:25 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-12 11:46:25 --> 404 Page Not Found --> processButtn/img
ERROR - 2014-12-12 11:46:32 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:46:32 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:46:32 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:46:32 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-12 11:46:32 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
ERROR - 2014-12-12 11:46:32 --> Severity: Warning  --> mcrypt_encrypt(): Attempt to use an empty IV, which is NOT recommend /var/www/html/pay/application/libraries/Paymentgateway.php 457
DEBUG - 2014-12-12 11:46:43 --> Final output sent to browser
DEBUG - 2014-12-12 11:46:43 --> Total execution time: 17.6453
DEBUG - 2014-12-12 11:46:43 --> Config Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Hooks Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Utf8 Class Initialized
DEBUG - 2014-12-12 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2014-12-12 11:46:43 --> URI Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Router Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Output Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Security Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Input Class Initialized
DEBUG - 2014-12-12 11:46:43 --> XSS Filtering completed
DEBUG - 2014-12-12 11:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-12 11:46:43 --> Language Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Loader Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Helper loaded: url_helper
DEBUG - 2014-12-12 11:46:43 --> Controller Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-12 11:46:43 --> Helper loaded: basic_helper
DEBUG - 2014-12-12 11:46:43 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Database Driver Class Initialized
ERROR - 2014-12-12 11:46:43 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-12 11:46:43 --> Encrypt Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-12 11:46:43 --> Session Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Helper loaded: string_helper
DEBUG - 2014-12-12 11:46:43 --> Session routines successfully run
DEBUG - 2014-12-12 11:46:43 --> Email Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:43 --> Model Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Database Driver Class Initialized
DEBUG - 2014-12-12 11:46:43 --> Helper loaded: cookie_helper
DEBUG - 2014-12-12 11:46:43 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:43 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:43 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:43 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-12 11:46:43 --> Helper loaded: form_helper
DEBUG - 2014-12-12 11:46:43 --> Form Validation Class Initialized
ERROR - 2014-12-12 11:46:43 --> 404 Page Not Found --> processTransaction/images
