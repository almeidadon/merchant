<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-12-11 19:52:33 --> Config Class Initialized
DEBUG - 2014-12-11 19:52:33 --> Hooks Class Initialized
DEBUG - 2014-12-11 19:52:33 --> Utf8 Class Initialized
DEBUG - 2014-12-11 19:52:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 19:52:33 --> URI Class Initialized
DEBUG - 2014-12-11 19:52:33 --> Router Class Initialized
ERROR - 2014-12-11 19:52:33 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:07:22 --> Config Class Initialized
DEBUG - 2014-12-11 20:07:22 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:07:22 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:07:22 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:07:22 --> URI Class Initialized
DEBUG - 2014-12-11 20:07:22 --> Router Class Initialized
ERROR - 2014-12-11 20:07:22 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:09:15 --> Config Class Initialized
DEBUG - 2014-12-11 20:09:15 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:09:15 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:09:15 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:09:15 --> URI Class Initialized
DEBUG - 2014-12-11 20:09:15 --> Router Class Initialized
ERROR - 2014-12-11 20:09:15 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:47:44 --> Config Class Initialized
DEBUG - 2014-12-11 20:47:44 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:47:44 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:47:44 --> URI Class Initialized
DEBUG - 2014-12-11 20:47:44 --> Router Class Initialized
ERROR - 2014-12-11 20:47:44 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:50:41 --> Config Class Initialized
DEBUG - 2014-12-11 20:50:41 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:50:41 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:50:41 --> URI Class Initialized
DEBUG - 2014-12-11 20:50:41 --> Router Class Initialized
ERROR - 2014-12-11 20:50:41 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:50:41 --> Config Class Initialized
DEBUG - 2014-12-11 20:50:41 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:50:41 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:50:41 --> URI Class Initialized
DEBUG - 2014-12-11 20:50:41 --> Router Class Initialized
ERROR - 2014-12-11 20:50:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-11 20:50:46 --> Config Class Initialized
DEBUG - 2014-12-11 20:50:46 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:50:46 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:50:46 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:50:46 --> URI Class Initialized
DEBUG - 2014-12-11 20:50:46 --> Router Class Initialized
ERROR - 2014-12-11 20:50:46 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:50:53 --> Config Class Initialized
DEBUG - 2014-12-11 20:50:53 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:50:53 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:50:53 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:50:53 --> URI Class Initialized
DEBUG - 2014-12-11 20:50:53 --> Router Class Initialized
ERROR - 2014-12-11 20:50:53 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:50:54 --> Config Class Initialized
DEBUG - 2014-12-11 20:50:54 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:50:54 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:50:54 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:50:54 --> URI Class Initialized
DEBUG - 2014-12-11 20:50:54 --> Router Class Initialized
ERROR - 2014-12-11 20:50:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-11 20:51:39 --> Config Class Initialized
DEBUG - 2014-12-11 20:51:39 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:51:39 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:51:39 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:51:39 --> URI Class Initialized
DEBUG - 2014-12-11 20:51:39 --> Router Class Initialized
ERROR - 2014-12-11 20:51:39 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:56:56 --> Config Class Initialized
DEBUG - 2014-12-11 20:56:56 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:56:56 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:56:56 --> URI Class Initialized
DEBUG - 2014-12-11 20:56:56 --> Router Class Initialized
ERROR - 2014-12-11 20:56:56 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:56:56 --> Config Class Initialized
DEBUG - 2014-12-11 20:56:56 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:56:56 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:56:56 --> URI Class Initialized
DEBUG - 2014-12-11 20:56:56 --> Router Class Initialized
ERROR - 2014-12-11 20:56:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-12-11 20:57:01 --> Config Class Initialized
DEBUG - 2014-12-11 20:57:01 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:57:01 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:57:01 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:57:01 --> URI Class Initialized
DEBUG - 2014-12-11 20:57:01 --> Router Class Initialized
ERROR - 2014-12-11 20:57:01 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:57:06 --> Config Class Initialized
DEBUG - 2014-12-11 20:57:06 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:57:06 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:57:06 --> URI Class Initialized
DEBUG - 2014-12-11 20:57:06 --> Router Class Initialized
ERROR - 2014-12-11 20:57:06 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 20:59:41 --> Config Class Initialized
DEBUG - 2014-12-11 20:59:41 --> Hooks Class Initialized
DEBUG - 2014-12-11 20:59:41 --> Utf8 Class Initialized
DEBUG - 2014-12-11 20:59:41 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 20:59:41 --> URI Class Initialized
DEBUG - 2014-12-11 20:59:41 --> Router Class Initialized
ERROR - 2014-12-11 20:59:41 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 21:06:06 --> Config Class Initialized
DEBUG - 2014-12-11 21:06:06 --> Hooks Class Initialized
DEBUG - 2014-12-11 21:06:06 --> Utf8 Class Initialized
DEBUG - 2014-12-11 21:06:06 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 21:06:06 --> URI Class Initialized
DEBUG - 2014-12-11 21:06:06 --> Router Class Initialized
ERROR - 2014-12-11 21:06:06 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 21:06:19 --> Config Class Initialized
DEBUG - 2014-12-11 21:06:19 --> Hooks Class Initialized
DEBUG - 2014-12-11 21:06:19 --> Utf8 Class Initialized
DEBUG - 2014-12-11 21:06:19 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 21:06:19 --> URI Class Initialized
DEBUG - 2014-12-11 21:06:19 --> Router Class Initialized
ERROR - 2014-12-11 21:06:19 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 21:06:52 --> Config Class Initialized
DEBUG - 2014-12-11 21:06:52 --> Hooks Class Initialized
DEBUG - 2014-12-11 21:06:52 --> Utf8 Class Initialized
DEBUG - 2014-12-11 21:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 21:06:52 --> URI Class Initialized
DEBUG - 2014-12-11 21:06:52 --> Router Class Initialized
ERROR - 2014-12-11 21:06:52 --> 404 Page Not Found --> undefined
DEBUG - 2014-12-11 21:08:41 --> Config Class Initialized
DEBUG - 2014-12-11 21:08:41 --> Hooks Class Initialized
DEBUG - 2014-12-11 21:08:41 --> Utf8 Class Initialized
DEBUG - 2014-12-11 21:08:41 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 21:08:41 --> URI Class Initialized
DEBUG - 2014-12-11 21:08:41 --> Router Class Initialized
ERROR - 2014-12-11 21:08:41 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 21:09:02 --> Config Class Initialized
DEBUG - 2014-12-11 21:09:02 --> Hooks Class Initialized
DEBUG - 2014-12-11 21:09:02 --> Utf8 Class Initialized
DEBUG - 2014-12-11 21:09:02 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 21:09:02 --> URI Class Initialized
DEBUG - 2014-12-11 21:09:02 --> Router Class Initialized
ERROR - 2014-12-11 21:09:02 --> 404 Page Not Found --> dashboard
DEBUG - 2014-12-11 22:55:04 --> Config Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Hooks Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Utf8 Class Initialized
DEBUG - 2014-12-11 22:55:04 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 22:55:04 --> URI Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Router Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Output Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Security Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Input Class Initialized
DEBUG - 2014-12-11 22:55:04 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 22:55:04 --> Language Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Loader Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Helper loaded: url_helper
DEBUG - 2014-12-11 22:55:04 --> Controller Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-11 22:55:04 --> Helper loaded: basic_helper
DEBUG - 2014-12-11 22:55:04 --> Helper loaded: form_helper
DEBUG - 2014-12-11 22:55:04 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Database Driver Class Initialized
ERROR - 2014-12-11 22:55:04 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-11 22:55:04 --> Encrypt Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-11 22:55:04 --> Session Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Helper loaded: string_helper
DEBUG - 2014-12-11 22:55:04 --> A session cookie was not found.
DEBUG - 2014-12-11 22:55:04 --> Session routines successfully run
DEBUG - 2014-12-11 22:55:04 --> Email Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:04 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:04 --> Helper loaded: cookie_helper
DEBUG - 2014-12-11 22:55:04 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:04 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:04 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:04 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:04 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:04 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-11 22:55:04 --> 404 Page Not Found --> v1/2703623476
DEBUG - 2014-12-11 22:55:08 --> Config Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Hooks Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Utf8 Class Initialized
DEBUG - 2014-12-11 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 22:55:08 --> URI Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Router Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Output Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Security Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Input Class Initialized
DEBUG - 2014-12-11 22:55:08 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:08 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 22:55:08 --> Language Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Loader Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Helper loaded: url_helper
DEBUG - 2014-12-11 22:55:08 --> Controller Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-11 22:55:08 --> Helper loaded: basic_helper
DEBUG - 2014-12-11 22:55:08 --> Helper loaded: form_helper
DEBUG - 2014-12-11 22:55:08 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Database Driver Class Initialized
ERROR - 2014-12-11 22:55:08 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-11 22:55:08 --> Encrypt Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-11 22:55:08 --> Session Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Helper loaded: string_helper
DEBUG - 2014-12-11 22:55:08 --> Session routines successfully run
DEBUG - 2014-12-11 22:55:08 --> Email Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:08 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Helper loaded: cookie_helper
DEBUG - 2014-12-11 22:55:08 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:08 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:08 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:08 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:08 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2014-12-11 22:55:08 --> File loaded: application/views/collect_mobileNo/header.php
DEBUG - 2014-12-11 22:55:08 --> File loaded: application/views/collect_mobileNo/body.php
DEBUG - 2014-12-11 22:55:08 --> File loaded: application/views/collect_mobileNo/footer.php
DEBUG - 2014-12-11 22:55:08 --> Final output sent to browser
DEBUG - 2014-12-11 22:55:08 --> Total execution time: 0.0689
DEBUG - 2014-12-11 22:55:08 --> Config Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Hooks Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Utf8 Class Initialized
DEBUG - 2014-12-11 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 22:55:08 --> URI Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Router Class Initialized
ERROR - 2014-12-11 22:55:08 --> 404 Page Not Found --> assets
DEBUG - 2014-12-11 22:55:08 --> Config Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Hooks Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Utf8 Class Initialized
DEBUG - 2014-12-11 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 22:55:08 --> URI Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Router Class Initialized
ERROR - 2014-12-11 22:55:08 --> 404 Page Not Found --> assets
DEBUG - 2014-12-11 22:55:08 --> Config Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Hooks Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Utf8 Class Initialized
DEBUG - 2014-12-11 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 22:55:08 --> URI Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Router Class Initialized
ERROR - 2014-12-11 22:55:08 --> 404 Page Not Found --> assets
DEBUG - 2014-12-11 22:55:08 --> Config Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Hooks Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Utf8 Class Initialized
DEBUG - 2014-12-11 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 22:55:08 --> URI Class Initialized
DEBUG - 2014-12-11 22:55:08 --> Router Class Initialized
ERROR - 2014-12-11 22:55:08 --> 404 Page Not Found --> assets
DEBUG - 2014-12-11 22:55:20 --> Config Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Hooks Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Utf8 Class Initialized
DEBUG - 2014-12-11 22:55:20 --> UTF-8 Support Enabled
DEBUG - 2014-12-11 22:55:20 --> URI Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Router Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Output Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Security Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Input Class Initialized
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> XSS Filtering completed
DEBUG - 2014-12-11 22:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-11 22:55:20 --> Language Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Loader Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Helper loaded: url_helper
DEBUG - 2014-12-11 22:55:20 --> Controller Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Helper loaded: payment_gateway_helper
DEBUG - 2014-12-11 22:55:20 --> Helper loaded: basic_helper
DEBUG - 2014-12-11 22:55:20 --> Helper loaded: form_helper
DEBUG - 2014-12-11 22:55:20 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Database Driver Class Initialized
ERROR - 2014-12-11 22:55:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-11 22:55:20 --> Encrypt Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Paymentgateway class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2014-12-11 22:55:20 --> Session Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Helper loaded: string_helper
DEBUG - 2014-12-11 22:55:20 --> Session routines successfully run
DEBUG - 2014-12-11 22:55:20 --> Email Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:20 --> Model Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Database Driver Class Initialized
DEBUG - 2014-12-11 22:55:20 --> Helper loaded: cookie_helper
DEBUG - 2014-12-11 22:55:20 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:20 --> Wallet_shmart class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:20 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:20 --> Notification_lib class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:20 --> Tank_auth class already loaded. Second attempt ignored.
DEBUG - 2014-12-11 22:55:20 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2014-12-11 22:55:20 --> Severity: 8192  --> mysql_escape_string(): This function is deprecated; use mysql_real_escape_string() instead. /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 319
ERROR - 2014-12-11 22:55:20 --> Severity: 8192  --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /var/www/html/pay/system/database/drivers/mysql/mysql_driver.php 73
DEBUG - 2014-12-11 22:55:20 --> File loaded: application/views/payment_page/header.php
DEBUG - 2014-12-11 22:55:20 --> File loaded: application/views/payment_page/body.php
DEBUG - 2014-12-11 22:55:20 --> File loaded: application/views/payment_page/footer.php
DEBUG - 2014-12-11 22:55:20 --> Final output sent to browser
DEBUG - 2014-12-11 22:55:20 --> Total execution time: 0.0976
