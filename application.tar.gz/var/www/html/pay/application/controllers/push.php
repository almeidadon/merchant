<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(E_ALL);
ini_set('display_errors', 1);
class Push extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('android_push_notification');
    }

    function index()
    {
		$data['shmart_refID'] = '61310077916405';
		$this->android_push_notification->transaction_alert_merchant($data);
	}
}