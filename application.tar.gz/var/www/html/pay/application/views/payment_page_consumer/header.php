<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Shmart!</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>assets/payment_page/css/bootstrap.css" rel="stylesheet">

    <!-- Boostrap Theme -->
    <link href="<?php echo base_url();?>assets/payment_page/css/theme-base.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/payment_page/css/boostrap-overrides.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/payment_page/css/theme.css" rel="stylesheet">
        
    <!-- Add custom CSS here -->
    <link href="<?php echo base_url();?>assets/payment_page/css/main-nav-horizontal.css" rel="stylesheet">
    
    <!-- Plugins -->
    <link href="<?php echo base_url();?>assets/payment_page/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/payment_page/css/ezmark.css">
    <link href="<?php echo base_url();?>assets/payment_page/css/animate-custom.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/payment_page/css/iosOverlay.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/payment_page/css/cards.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/payment_page/css/cc-logo.css" rel="stylesheet">
	
   <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
    <![endif]-->
	
    
</head>