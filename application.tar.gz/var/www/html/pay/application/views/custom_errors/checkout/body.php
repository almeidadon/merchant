<body>
<section id="content" class="m-t-lg wrapper-md animated fadeInUp">
<div class="nav-brand"><img src="//pay.shmart.in/assets_todo/images/shmart_transparent.png" /></div>
    <div class="row m-n">
        <div class="col-md-6 col-md-offset-3 m-t-lg">
            <section class="panel">
                <form action="index.html" class="panel-body">
                    <header class="panel-heading text-center">
                        <section class="panel bg-danger lter no-borders">
                            <div class="panel-body text-center">
                                <a class="pull-right" href="#"></a>
                                <div class="text-center padder m-t">
                                    <span class="h2"><i class="icon-remove-circle text-muted"></i>Access Denied!</span>
                                </div>
                            </div>
                            <footer class="panel-footer lt">
                                <div class="row">
                                    <div class="col-xs-2">
<!--                                        <strong class="text-muted">Error Code : --><?php //echo $api_error_code; ?><!--</strong>-->
                                        <strong><span></span></strong>
                                    </div>
                                    <div class="col-xs-8">
                                        <strong class="text-muted"><?php echo $api_error; ?></strong>
                                        <strong><span></span></strong>
                                    </div>
                                    <div class="col-xs-2">
                                    </div>
                                </div>
                            </footer>
                        </section>
                    </header>
                    <form action="index.html" class="panel-body">
                        <section class="panel">
                            <header class="panel-heading">
                                <span class="badge bg-info pull-right"><i class="icon-paper-clip"></i></span>API error</header>
                            <section class="panel-body">
                                <article class="media">
                                    <div class="pull-left thumb-sm">
                      <span class="icon-stack">
                        <i class="icon-circle text-success icon-stack-base"></i>
                        <i class="icon-inr icon-light"></i>
                      </span>
                                    </div>
                                    <div class="media-body">
                                        <div class="pull-right media-xs text-center text-muted">
                                            <strong class="h4"></strong><br>

                                        </div>
                                        <a href="#" class="h4"><?php echo $api_error; ?></a>
                                        <small class="block m-t-sm">Contact wecare@shmart.in with the error code for more info</small>
                                    </div>
                                </article>
                                <div class="line pull-in"></div>
                            </section>
                        </section>

                    </form>
            </section>
                        <!--                    <div class="form-group">-->
<!--                        <label class="control-label">Email</label>-->
<!--                        <input type="email" placeholder="test@example.com" class="form-control">-->
<!--                    </div>-->
<!--                    <div class="form-group">-->
<!--                        <label class="control-label">Password</label>-->
<!--                        <input type="password" id="inputPassword" placeholder="Password" class="form-control">-->
<!--                    </div>-->
<!--                    <div class="checkbox">-->
<!--                        <label>-->
<!--                            <input type="checkbox"> Keep me logged in-->
<!--                        </label>-->
<!--                    </div>-->
<!--                    <a href="#" class="pull-right m-t-xs"><small>Forgot password?</small></a>-->
<!--                    <button type="submit" class="btn btn-info">Sign in</button>-->
<!--                    <div class="line line-dashed"></div>-->
<!--                    <a href="#" class="btn btn-facebook btn-block m-b-sm"><i class="icon-facebook pull-left"></i>Sign in with Facebook</a>-->
<!--                    <a href="#" class="btn btn-twitter btn-block"><i class="icon-twitter pull-left"></i>Sign in with Twitter</a>-->
<!--                    <div class="line line-dashed"></div>-->
<!--                    <p class="text-muted text-center"><small>Do not have an account?</small></p>-->
<!--                    <a href="signup.html" class="btn btn-white btn-block">Create an account</a>-->
                </form>
            </section>
        </div>
    </div>
</section>
<!-- footer -->
<footer id="footer">
    <div class="text-center padder clearfix">
        <p>
            <small>www.shmart.in<br>&copy; 2014</small>
        </p>
    </div>
</footer>
