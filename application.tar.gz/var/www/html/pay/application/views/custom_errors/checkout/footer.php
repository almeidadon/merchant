<!-- Bootstrap -->
<script src="<?php echo base_url();?>/assets_todo/js/bootstrap.js"></script>
<!-- App -->
<script src="<?php echo base_url();?>/assets_todo/js/app.js"></script>
<script src="<?php echo base_url();?>/assets_todo/js/app.plugin.js"></script>
<script src="<?php echo base_url();?>/assets_todo/js/app.data.js"></script>
<!-- Fuelux -->
<script src="<?php echo base_url();?>/assets_todo/js/fuelux/fuelux.js"></script>
<script src="<?php echo base_url();?>assets_todo/js/iosOverlay.js"></script>
<script src="<?php echo base_url();?>assets_todo/js/spin.min.js"></script>
<script src="<?php echo base_url();?>assets_todo/js/icheck.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/cardvalidation.js"></script>
<script type="text/javascript" cache="false" src="<?php echo base_url();?>assets/js/cardlogodisplay.js"></script>