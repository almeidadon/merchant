<?php 


echo '<html>
				<body>
				<form id="pay" action="'.$posturl.'" method="POST" >'.$input_fields.'</form>
				<script>document.getElementById("pay").submit();</script>
				</body>
				</html>';



?>