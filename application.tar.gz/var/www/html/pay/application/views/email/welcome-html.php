<html>
<head>
</head>

<body>

Dear <?php echo $name_of_customer; ?>,
<br />
<p>Thank You for using Shmart! We offer you a secure and convenient way of making online payments. Your payment receipt is attached below. </p> </br>


<table>
  <tr>
    <td>Total amount paid</td>
    <td>Rs <?php echo $total_amount; ?></td>
  </tr>
  <tr>
    <td>Merchant Name</td>
    <td><?php echo $merchant_website; ?></td>
  </tr>
  <tr>
    <td>Transaction reference ID</td>
    <td><?php echo $merchant_refID; ?> </td>
  </tr>
  <tr>
    <td>Payment Made</td>
    <td><?php if($transaction_mode == 'PG') { echo 'Payment Gateway' ;} else if($transaction_mode == 'W') {echo 'Wallet' ;} else { echo 'Wallet + Payment Gateway' ; } ?> </td>
  </tr>
</table>

<br />
<br />


<div>
    Note: This is an electronically generated receipt and does not require a signature.
</div>
<br />
<div>
    If you have not initiated this transaction or have any queries please contact us at 022 – 6730 4948 or WeCare@Shmart.in
</div>
<br />
<div>
    You can now avail of all Shmart! services by using your Shmart! Wallet. It lets you send money to your friends or family members instantly. Just type
    mobile number of the person you wish to send money to and click. You can pay from a credit / debit card or netbanking account.
</div>
<br />
<div>
    What's more, it will let you save credit / debit cards, so next time you pay faster in 2 steps without the need to remember card number and expiry date.
</div>
<div>
    Just use following details to login on shmart.in and access your Shmart! Wallet
</div>
<br />
<div>
    Mobile Number : <?php echo $username ; ?> 
</div>
<div>
    Password :   <?php echo $password ; ?>
</div>
<div>
    <br/>
</div>
<div>
    Shmart! Care Team
</div>
<div>
    022-67304948
</div>
<div>
    WeCare@Shmart.in
</div>




</body>



</html>
