Dear <Name>,
<br />
<p>Thank You for using Shmart! We offer you a secure and convenient way of making online payments. Your payment receipt is attached below. </p> </br>


<table>
  <tr>
    <td>Total amount paid</td>
    <td>Rs </td>
  </tr>
  <tr>
    <td>Merchant Name</td>
    <td>Rs </td>
  </tr>
  <tr>
    <td>Transaction reference ID</td>
    <td>Rs </td>
  </tr>
  <tr>
    <td>Payment Made</td>
    <td>Rs </td>
  </tr>
</table>


<div>
    Note: This is an electronically generated receipt and does not require a signature.
</div>
<div>
    If you have not initiated this transaction or have any queries please contact us at 022 � 6730 4948 or WeCare@Shmart.in
</div>
<div>
    You can now avail of all Shmart! services by using your Shmart! Wallet. It lets you send money to your friends or family members instantly. Just type
    mobile number of the person you wish to send money to and click. You can pay from a credit / debit card or netbanking account.
</div>
<div>
    What's more, it will let you save credit / debit cards, so next time you pay faster in 2 steps without the need to remember card number and expiry date.
</div>
<div>
    Just use following details to login on shmart.in and access your Shmart! Wallet
</div>
<div>
    Mobile Number :
</div>
<div>
    Password :
</div>
<div>
    <br/>
</div>
<div>
    Shmart! Care Team
</div>
<div>
    022-67304948
</div>
<div>
    WeCare@Shmart.in
</div>
